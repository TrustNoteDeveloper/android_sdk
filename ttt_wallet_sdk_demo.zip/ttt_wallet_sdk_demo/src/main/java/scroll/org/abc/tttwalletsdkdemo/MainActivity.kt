package scroll.org.abc.tttwalletsdkdemo

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import org.trustnote.wallet.sdk.TTTWalletSDK

class MainActivity : AppCompatActivity() {


    private var currentMnemonic = ""
    private var currentPrivkey = ""
    private var currentWalletPubkey = ""
    private var currentPubKey = ""
    private var currentAddress = ""
    private var currentSignautre = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        TTTWalletSDK.init(applicationContext)
    }

    fun createMnemonic(v: View) {
        Thread {
            val mnemonic = TTTWalletSDK.createMnemonic()
            currentMnemonic = mnemonic
            runOnUiThread {
                runOnUiThread {
                    printLog("mnemonic: $mnemonic")
                    enableBtn(R.id.createPrivateKey)
                }
            }
        }.start()
    }

    fun createPrivateKey(v: View) {
        Thread {
            val privatekey = TTTWalletSDK.createPrivateKey(currentMnemonic)
            currentPrivkey = privatekey
            runOnUiThread {
                runOnUiThread {
                    printLog("private key: $privatekey")
                    enableBtn(R.id.createWallet)
                }
            }
        }.start()
    }

    fun createWallet(v: View) {
        Thread {
            val walletPubkey = TTTWalletSDK.createWallet(currentPrivkey)
            currentWalletPubkey = walletPubkey
            runOnUiThread {
                runOnUiThread {
                    printLog("wallet pub-key: $walletPubkey")
                    enableBtn(R.id.createPublickey)
                }
            }
        }.start()
    }

    fun createPublickey(v: View) {
        Thread {
            val pubKey = TTTWalletSDK.createPublickey(currentWalletPubkey)
            currentPubKey = pubKey
            runOnUiThread {
                runOnUiThread {
                    printLog("pubKey: $pubKey")
                    enableBtn(R.id.createAddress)
                }
            }
        }.start()
    }

    fun createAddress(v: View) {
        Thread {
            val address = TTTWalletSDK.createAddress(currentWalletPubkey)
            currentAddress = address
            runOnUiThread {
                runOnUiThread {
                    printLog("address: $address")
                    enableBtn(R.id.isValidAddress)
                }
            }
        }.start()
    }

    fun isValidAddress(v: View) {
        Thread {
            val isValid = TTTWalletSDK.isValidAddress(currentAddress)
            runOnUiThread {
                runOnUiThread {
                    printLog("isValidAddress: $isValid")
                    enableBtn(R.id.sign)
                }
            }
        }.start()
    }

    fun sign(v: View) {
        Thread {
            val signature = TTTWalletSDK.sign(currentPrivkey, "qnGUSJUBLxvmBK1IswPeQnmEWN2wSi4ACf5lJn6pLzY=")
            currentSignautre = signature
            runOnUiThread {
                runOnUiThread {
                    printLog("sign: $signature")
                    enableBtn(R.id.verify)
                }
            }
        }.start()
    }

    fun verify(v: View) {
        Thread {
            val res = TTTWalletSDK.verify(currentPubKey, currentSignautre, "qnGUSJUBLxvmBK1IswPeQnmEWN2wSi4ACf5lJn6pLzY=")
            runOnUiThread {
                runOnUiThread {
                    printLog("verify: $res")
                }
            }
        }.start()
    }

    private fun printLog(log: String) {
        val logTextView = findViewById<TextView>(R.id.log)
        logTextView.text = log + "\n\r\n\r" + logTextView.text.toString()
    }

    private fun enableBtn(btnResId: Int) {
        findViewById<Button>(btnResId).isEnabled = true
    }

}
